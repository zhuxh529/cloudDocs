[puma]=pumaInit();
[ handles ] = drawPuma( [0,0,0,0,0,0], puma);