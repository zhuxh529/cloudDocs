function a=actuator2joint(actuator_angles) 
	a=actuator_angles.*[8.61,6.93,6.93];
end