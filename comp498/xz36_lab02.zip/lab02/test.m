%PROBLEM 3
m=rpytf([ 0.5, 0.6, -0.2,pi/2, pi/4, pi/18]);
drawFrame(m, [ 1 1 1]);