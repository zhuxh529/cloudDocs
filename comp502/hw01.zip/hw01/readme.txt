homework is written in hm01.docx
